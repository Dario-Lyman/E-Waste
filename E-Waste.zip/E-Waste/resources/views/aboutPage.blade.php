@extends('layout.layout')

@section('content')
    <div class="row mx-1 my-3"></div>
    <div class="row mx-1 mt-5">
        <div class="col">
            <h5>E-Waste is a ..........</h5>
        </div>
    </div>
@endsection