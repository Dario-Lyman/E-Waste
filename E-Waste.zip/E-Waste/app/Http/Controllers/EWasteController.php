<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EWasteController extends Controller
{
    //
}
