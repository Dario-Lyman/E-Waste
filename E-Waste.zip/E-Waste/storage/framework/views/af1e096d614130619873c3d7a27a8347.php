

<?php $__env->startSection('content'); ?>
    <div class="row mx-1 my-3"></div>
    <div class="row mx-1 mt-5">
        <div class="col">
            <h5>E-Waste is a ..........</h5>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive - Bina Nusantara\Documents\Laravel Projects\Final Project Web Prog\E-Waste\resources\views/aboutPage.blade.php ENDPATH**/ ?>